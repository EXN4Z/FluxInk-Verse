import type React from "react";
import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { Eye, ArrowLeft, Star, BookOpen, Calendar } from "lucide-react";

import { COMICS, ComicItem, formatCompactID, formatDateID } from "@/lib/comics";
import ChapterList from "./ChapterList";

type Chapter = {
  number: number;
  title?: string;
  volume?: number;
  releasedAt?: string;
};

const VOLUME_SIZE = 10;

// =======================
// Helpers
// =======================
function getChapters(comic: ComicItem): Chapter[] {
  const maybe = (comic as ComicItem & { chapters?: Chapter[] }).chapters;
  if (Array.isArray(maybe) && maybe.length) return maybe;

  const total = comic.lastChapter ?? 0;
  return Array.from({ length: total }, (_, i) => ({
    number: i + 1,
    title: `Chapter ${i + 1}`,
    volume: Math.ceil((i + 1) / VOLUME_SIZE),
  }));
}

// =======================
// SSG params
// =======================
export function generateStaticParams() {
  return COMICS.map((c) => ({ slug: c.slug }));
}

// =======================
// Page
// =======================
export default function KomikDetailPage({
  params,
}: {
  params: { slug?: string | string[] };
}) {
  // 🛡️ SAFE SLUG HANDLING
  const raw = params?.slug;
  const slug = Array.isArray(raw) ? raw[0] : raw;

  if (!slug) notFound();

  const key = decodeURIComponent(String(slug)).trim().toLowerCase();

  const comic = COMICS.find(
    (c) => c.slug.trim().toLowerCase() === key
  );

  if (!comic) notFound();

  const chapters = getChapters(comic);
  const totalChapters = chapters.length || comic.lastChapter || 0;

  const synopsis =
    (comic as ComicItem & { synopsis?: string }).synopsis?.trim() ||
    comic.note?.trim() ||
    "Belum ada sinopsis.";

  const totalVolumes = Math.max(1, Math.ceil(totalChapters / VOLUME_SIZE));

  return (
    <section className="relative w-full overflow-hidden bg-gradient-to-b from-zinc-950 via-zinc-900 to-zinc-950 text-white">
      <div className="relative mx-auto max-w-7xl px-6 py-10 md:py-14">
        {/* Back */}
        <Link
          href="/komik"
          className="inline-flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm text-white/75 ring-1 ring-white/10 hover:bg-white/10"
        >
          <ArrowLeft className="h-4 w-4" />
          Balik ke Explore
        </Link>

        {/* Header */}
        <div className="mt-6 grid gap-6 lg:grid-cols-[320px_1fr]">
          {/* Cover */}
          <div className="rounded-3xl bg-white/5 p-4 ring-1 ring-white/10 backdrop-blur">
            <div className="relative aspect-[3/4] overflow-hidden rounded-2xl bg-white/10 ring-1 ring-white/10">
              <Image
                src={comic.cover}
                alt={comic.title}
                fill
                className="object-cover object-top"
              />
            </div>

            <div className="mt-4 grid gap-2 text-sm text-white/75">
              <Stat label="Views" value={formatCompactID(comic.views ?? 0)} icon={<Eye />} />
              <Stat label="Rating" value={comic.rating?.toFixed(1) ?? "—"} icon={<Star />} />
              <Stat label="Update" value={formatDateID(comic.updatedAt)} icon={<Calendar />} />
            </div>
          </div>

          {/* Info */}
          <div className="rounded-3xl bg-white/5 p-6 ring-1 ring-white/10 backdrop-blur">
            <div className="flex flex-wrap gap-2">
              {comic.status && (
                <Badge>{comic.status}</Badge>
              )}
              <Badge>{totalChapters} Chapter</Badge>
              <Badge>{totalVolumes} Volume</Badge>
            </div>

            <h1 className="mt-3 text-3xl font-extrabold">{comic.title}</h1>

            <p className="text-sm text-white/65">
              Author:{" "}
              <span className="font-semibold text-white/85">
                {comic.author ?? "—"}
              </span>
            </p>

            {/* Tags */}
            <div className="mt-2 flex flex-wrap gap-2">
              {comic.tags?.map((t) => (
                <Badge key={t}>{t}</Badge>
              ))}
            </div>

            {/* Sinopsis */}
            <div className="mt-4 rounded-2xl bg-black/25 p-4 ring-1 ring-white/10">
              <div className="mb-2 flex items-center gap-2 font-semibold">
                <BookOpen className="h-4 w-4" />
                Sinopsis
              </div>
              <p className="text-sm text-white/70 leading-relaxed">
                {synopsis}
              </p>
            </div>

            {/* CTA */}
            <div className="mt-4 flex gap-3">
              <Link
                href={`/komik/${comic.slug}/chapter/1`}
                className="rounded-2xl bg-white px-5 py-3 text-sm font-semibold text-black"
              >
                Baca dari Awal
              </Link>
              <Link
                href={`/komik/${comic.slug}/chapter/${totalChapters}`}
                className="rounded-2xl bg-white/10 px-5 py-3 text-sm font-semibold text-white ring-1 ring-white/15"
              >
                Chapter Terbaru
              </Link>
            </div>
          </div>
        </div>

        {/* Chapter List */}
        <div className="mt-8">
          <ChapterList
            slug={comic.slug}
            updatedAt={comic.updatedAt}
            chapters={chapters}
          />
        </div>
      </div>
    </section>
  );
}

// =======================
// UI bits
// =======================
function Badge({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full bg-white/10 px-3 py-1 text-xs text-white/70 ring-1 ring-white/10">
      {children}
    </span>
  );
}

function Stat({
  label,
  value,
  icon,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between">
      <span className="inline-flex items-center gap-2">
        {icon}
        {label}
      </span>
      <span className="font-semibold text-white/90">{value}</span>
    </div>
  );
}
