export default function ProfilePage() {
  return <div>Profile</div>
}
